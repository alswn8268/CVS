function openWin() {	
	let url = './itemImageInsert.jsp';
	let title = '사진 업로드';
	let option = 'top=100px, left=100px, width=800px, height=800px';
	window.open(url, title, option);
}