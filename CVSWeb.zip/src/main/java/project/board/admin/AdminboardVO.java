package project.board.admin;

import java.util.Date;

public class AdminboardVO {

	
}